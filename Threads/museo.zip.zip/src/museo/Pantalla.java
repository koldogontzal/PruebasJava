package museo;

public class Pantalla {

	synchronized public static void println(String t) {
		System.out.println(t);
	}
}
